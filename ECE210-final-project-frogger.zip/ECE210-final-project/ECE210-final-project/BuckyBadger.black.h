
#ifndef __BUCKY_H__
#define __BUCKY_H__

#include "ece210_api.h"

extern const uint8_t bucky_bitmap[];
#define BUCKY_WIDTH_PXL 96
#define BUCKY_HEIGHT_PXL 12

#endif
