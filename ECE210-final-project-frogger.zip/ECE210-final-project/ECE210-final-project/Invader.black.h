
#ifndef __INVADERS_H__
#define __INVADERS_H__

#include "ece210_api.h"

extern const uint8_t invader_bitmap[];
#define INVADER_WIDTH_PXL 24
#define INVADER_HEIGHT_PXL 16

#endif
