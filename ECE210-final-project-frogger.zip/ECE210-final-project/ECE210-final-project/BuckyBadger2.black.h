#ifndef __BUCKY2_H__
#define __BUCKY2_H__

#include "ece210_api.h"

extern const uint8_t bucky_2_bitmap[];
#define BUCKY2_WIDTH_PXL 48
#define BUCKY2_HEIGHT_PXL 12

#endif
