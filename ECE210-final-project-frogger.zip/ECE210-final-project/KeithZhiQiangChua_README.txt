Project Title: ECE210 Final Project - Frogger
Your Name: Keith Chua
Team Members: Justin Griesemer

Project Instructions: Our final project is a 2 player frogger game where 2 players race to complete the game. 
			The player which first reaches the finish 3 times wins. In order to player the game on two
			board simultaneously, do remember to change the local and remote ID's correspondingly to
			match your own ID. Compile the main.c file found in the folder and load it on to your board.
			If the frogger hits an obstacle and dies, he will turn red and the board must be reset to
			be played again.

My role in the project: I worked on half of the flowchart and half of the code.


Workload Breakdown: Justin and I both contributed equally.    
		

What I learned from the project: I learned the syntax of C programming and learned the value of drawing
				a flowchart before beginning to write your program. I also learned about the 
				motherboard and how to do soldering.

Suggestions: I feel that those who take this course and have no prior programming experiences would probably face a
		lot of difficulties, especially with common programming concepts like while loops etc. Fortunately for
		me, this isn’t my first time programming and I had to only familiarise myself with the syntax of C. 
		I understand that a workaround to using C to program is pretty difficult but maybe even more 			abstraction of the programming tasks could be done to make it easier to handle.

Youtube Video Link: https://www.youtube.com/watch?v=JgEZSPQM3oc&feature=youtu.be 